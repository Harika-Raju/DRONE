import React from 'react';
import './Settings.css';

function Settings() {
  return (
    <div className="settings">
      <h3>Settings</h3>
      <p>Configure system settings here.</p>
    </div>
  );
}

export default Settings;
