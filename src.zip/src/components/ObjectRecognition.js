import React from 'react';
import './ObjectRecognition.css';

function ObjectRecognition() {
  return (
    <div className='object-recognition'>
      <h3>Object Recognition</h3>
      <p>Details about the object recognition feature will go here.</p>
    </div>
  );
}

export default ObjectRecognition;
