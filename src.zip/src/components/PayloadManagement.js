import React from 'react';
import "./PayloadManagement.css";

function PayloadManagement() {
  return (
    <div className="payload-management">
      <h3>Payload Management</h3>
      <p>Manage payloads for the drones from this section.</p>
    </div>
  );
}

export default PayloadManagement;
