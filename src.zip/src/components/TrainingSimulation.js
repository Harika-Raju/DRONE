import React from 'react';
import './TrainingSimulation.css';

function TrainingSimulation() {
  return (
    <div className='training-simulation'>
      <h3>Training & Simulation</h3>
      <p>Train operators and simulate missions here.</p>
    </div>
  );
}

export default TrainingSimulation;
